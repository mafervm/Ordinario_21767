package com.example.ordinario_21767.viewmodels

import androidx.lifecycle.ViewModel
import com.example.ordinario_21767.R
import com.example.ordinario_21767.models.Cards

class CardViewModel: ViewModel() {
    init {}

    fun getCardList(): ArrayList<Cards> {

        var cardList: ArrayList<Cards> = ArrayList<Cards>()

        cardList.add (Cards("#1", "Adivina la edad", R.drawable.pastel))
        cardList.add (Cards("#2", "Gatos", R.drawable.gato))
        cardList.add (Cards("#3", "NBA", R.drawable.nba))
        cardList.add (Cards("#4", "Chuck Norris", R.drawable.chucknorris))

        //
        return cardList //regresamos la lista de juegos
    }
}