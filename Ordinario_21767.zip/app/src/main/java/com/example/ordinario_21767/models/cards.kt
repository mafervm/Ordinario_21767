package com.example.ordinario_21767.models

import androidx.annotation.DrawableRes

data class Cards(
    val numero: String,
    val titulo: String,
    @DrawableRes val image: Int
)
